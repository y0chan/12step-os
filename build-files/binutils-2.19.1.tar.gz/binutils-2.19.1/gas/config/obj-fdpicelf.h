#define OBJ_FDPIC_ELF 1
#include "obj-elf.h"
